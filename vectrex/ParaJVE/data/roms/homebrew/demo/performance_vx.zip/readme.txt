-----------------------------------------------------------------------------
			      /////////////////
	                      //////////////////
        	              ////          ////
	               	      ////   ///////////
	                      ////  ///////////
                              ////  ////
                              ////  ///////////
                              ////   //////////

	     	   	   www.revival-studios.com
-----------------------------------------------------------------------------
Title		:	Performance VX 
Author		:	Martijn Wenting / Revival Studios
Genre		:	Demo
System		:	Vectrex
Date		:	18/11/2003 
Product ID	:	RS-VX001
-----------------------------------------------------------------------------

All the contents of this cart are (c)copyright 2003-2007 Revival Studios.
The contents of the package may only be spread in its original form, and may not be
published or distributed otherwise without the written permission of the authors.

Introduction:
-------------
Performance VX has been my second demo on the vectrex back in 2003 and features a total of 5 different effects, synchronised to the music.
The demo was then released for private use in very limited copies, but has later been included on the "3D scape cartridge" as part of a demo collection,
which will have a budget release in 2007.

Running the demo:
-----------------
Please run the demo on the real hardware, or otherwise use ParaJVE. 
Also, a video is included for people who aren't able to watch it on the real hardware.

Credits:
--------
Programming & Design by: Martijn Wenting
Music by: Faried Verheul

Distribution:
-------------
This package can be freely distributed in its original form.
The ROM image can not be included on multicarts without written permission.

If you would like to own this demo on cartridge. Please look out for the 3D scape 
demo cartridge, which will also include my first demo "oldskool +3 (2002)", and 
an interactive 3D landscape demo.

Watch out for more releases soon!


	Martijn Wenting

