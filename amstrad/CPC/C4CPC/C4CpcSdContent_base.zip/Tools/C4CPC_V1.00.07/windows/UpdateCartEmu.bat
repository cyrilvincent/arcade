@ECHO off
dfu-programmer atmega32u4 get manufacturer
if  %ERRORLEVEL% EQU 0 (
    echo "--- Erase ---"
    dfu-programmer atmega32u4 erase --force
    echo "--- Flash ---"
    dfu-programmer atmega32u4 flash ..\C4CPC-V1_00_07.hex
    echo "--- EEProm ---"
    dfu-programmer atmega32u4 flash --eeprom --force ..\C4CPC-V1_00_07.eep
) else (
    echo "No card detected"
)
