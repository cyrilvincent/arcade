Requires pyserial to be installed: pip3 install pyserial

Loading a local cartridge file to cartridge emulator :
python3 C4CpcCom.py -p port cart.crp 
where port is the virtual serial port of the cartridge emulator (COMx on windows, /dev/ttyACMx on linux)
