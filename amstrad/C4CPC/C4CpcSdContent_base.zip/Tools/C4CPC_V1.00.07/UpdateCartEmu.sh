#!/bin/sh

if dfu-programmer atmega32u4 get manufacturer
then
    echo "--- Erase ---"
    dfu-programmer atmega32u4 erase --force
    echo "--- Flash ---"
    dfu-programmer atmega32u4 flash C4CPC-V1_00_07.hex
    echo "--- EEProm ---"
    dfu-programmer atmega32u4 flash --eeprom --force C4CPC-V1_00_07.eep
    echo "--- Restart ---"
    dfu-programmer atmega32u4 launch
else
    echo "No card detected"
fi
