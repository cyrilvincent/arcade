This archive contains the latest version of C4CPC firmware and CprSelect as well as upgrade script and tools.

1. Changes
[FW_V1_00_07]
Fixed issue that loaded more sectors than remaining in current cluster.

[FW_V1_00_06] (unreleased)
Enabled warmboot in bootloader. Sould fix reset issue with M4 issuing multiple reset.

[FW_V1_00_05]
Fixed cluster trucation error leading to crash when loaded files where on cluster number greater that 65536.

[FW_V1_00_04]
Added support for Symbiface II in bootstrap : when symbiface is detected, its expansion ROM will be disabled as long as communication is needed between C4CPC microcontroller and CPC. Bootstrap will then enable the ROM when starting loaded CPR.
Fixed and improved command handling resulting in faster response time and bug free hqndling of file access from CPC.

[CprSelect_V1.02]
Added support for Symbiface II. Symbiface ROM will be disabled when entering CprSelect. The ROM will NOT be enabled when starting the loaded CPR, this would prevent some games working.
Added text viewer to file browser. Currently limited to 5210 lines.
CprSelect require FW V1_00_04 for text display.


[FW_V1_00_03]
FAT handling : Fix bad behaviour in file read that may read more sector than available in a cluster

[FW_V1_00_02]
This update fix an issue in directory list management that prevent browsing reliably folders with more than 247 files.

2.1 Requirement :
Update procedure requires the dfu-programmer software: 
- Executable version is provided for windows users.
- Linux users should find it in they distribution repository or build it from source.
- OSX users will have to build it from provided source and script in dfu-programmer_install_OSX. 


2.2 Start C4CPC in usb update mode
- put dip switch 4 ON
- connect the card in one USB port
- press and release the C4CPC reset switch

The C4CPC should appear as a ATmega32U4 on windows or ATm32U4DFU on linux/osx :
kernel: usb 2-1.5: New USB device found, idVendor=03eb, idProduct=2ff4
kernel: usb 2-1.5: New USB device strings: Mfr=1, Product=2, SerialNumber=3
kernel: usb 2-1.5: Product: ATm32U4DFU
kernel: usb 2-1.5: Manufacturer: ATMEL
kernel: usb 2-1.5: SerialNumber: 1.0.0

2.3 Install DFU driver (Windows only)
After the reset, windows will look for the device drivers. These are located in 
windows\dfu-prog-usb-1.2.2

2.4 Update the card

To update the card, just execute the appropriate script from a terminal :
- UpdateCartEmu.sh on Linux/OSX
- UpdateCartEmu.bat on windows from the windows directory

A successful update looks like this :
   Manufacturer Code: 0x58 (88)
   --- Erase ---
   Erasing flash...  Success
   Checking memory from 0x0 to 0x6FFF...  Empty.
   --- Flash ---
   Checking memory from 0x0 to 0x4DFF...  Empty.
   0%                            100%  Programming 0x4E00 bytes...
   [>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>]  Success
   0%                            100%  Reading 0x7000 bytes...
   [>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>]  Success
   Validating...  Success
   0x4E00 bytes written into 0x7000 bytes memory (69.64%).
   --- EEProm ---
   0%                            100%  Programming 0x380 bytes...
   [>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>]  Success
   0%                            100%  Reading 0x400 bytes...
   [>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>]  Success
   Validating...  Success
   0x380 bytes written into 0x400 bytes memory (87.50%).

2.5 Check that card is updated
Starting the card without a SD card will display the CPC bootloader screen. C4CPC version is visible on left bottom corner.


3. CprSelect update
Lasted version of CrpSelect is CprSelect_v101.cpr and should replace the one in slot15 (_C4CPC/F)
