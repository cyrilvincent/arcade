This archive contains latest dfu-programmer and libusb sources and a makefile to build a working version of dfu-programmer on mac OSx.

To build dfu-programmer :
- open a terminal and move to the dfu-programmer_install_OSX folder
- invoke the makefile : make

At this point, if xcode is not installed, you should be prompted for install. Install XCODE, and restart the make once XCODE is installed.

- make will first build and install libusb if it is not already available on your setup, then build and install dfu-programmer.
- You will be prompted for your password during the install process

Except few compilation warning, the process should work.
Invoking dfu-programmer on the command line should yield :

dfu-programmer 0.7.2
https://github.com/dfu-programmer/dfu-programmer
Type 'dfu-programmer --help'    for a list of commands
     'dfu-programmer --targets' to list supported target devices
